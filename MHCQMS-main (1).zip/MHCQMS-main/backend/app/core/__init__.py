# Core configuration module
